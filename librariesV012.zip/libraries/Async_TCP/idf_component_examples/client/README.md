### Basic example to show how AsyncTCP client works
